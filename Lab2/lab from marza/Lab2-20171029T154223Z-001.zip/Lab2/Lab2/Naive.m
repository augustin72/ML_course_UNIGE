function [ output_args ] = Naive( input_args )
%NAIVE Summary of this function goes here
%   Detailed explanation goes here


end

