function [ output_args ] = set( training, test )




end

