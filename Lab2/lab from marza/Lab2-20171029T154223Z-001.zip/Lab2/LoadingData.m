
clear;
clc;
x=load('Dataset.txt');

% x=x(randperm(size(x,1)),:);
training=x(1:14,:);
test=x(11:14,1:4);
target=x(11:14,5);

[targetTest,errorRate]=FunctionCall(training,test,target);



    


