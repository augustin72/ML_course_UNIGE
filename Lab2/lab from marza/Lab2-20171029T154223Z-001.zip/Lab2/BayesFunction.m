function [ targetTest ] = BayesFunction(training, test, varargin )

[rowTraining, columnTraining]=size(training);
[rowTest, columnTest]=size(test);
Yes=length(find(training(:,5)==1));
probYes=Yes/rowTraining;
No=length(find(training(:,5)==2));
probNo=No/rowTraining;
for i=1:columnTraining-1
    componentValues(i)={unique(training(:,i))};
end
for i=1:length(componentValues)
    maxValue(i)=max(componentValues{i});
    for j=1:maxValue(i)
        event{j,i}=find(training(:,i)==j);
        prob1{j,i}=find(training(event{j,i},5)==1);
        probLength1{j,i}=length(prob1{j,i});
        probEventYes{j,i}=probLength1{j,i}/Yes;
        prob2{j,i}=find(training(event{j,i},5)==2);
        probLength2{j,i}=length(prob2{j,i});
        probEventNo{j,i}=probLength2{j,i}/No;
        
    end
end



for i=1:rowTest
    for j=1:columnTest
        k=test(i,j);
        probEventTestYes(i,j)=probEventYes{k,j};
        probEventTestNo(i,j)=probEventNo{k,j};
    end
end

probEventTestYes=prod(probEventTestYes,2);
probEventTestNo=prod(probEventTestNo,2);
testFunctionYes=probYes.*probEventTestYes;
testFunctionNo=probNo.*probEventTestNo;
figure(1)
data=[testFunctionYes,testFunctionNo];
figure(1)
bar(data);
title('Probability of playing');
legend('Yes','No');


for i=1:rowTest
    if(testFunctionYes(i)>testFunctionNo(i))
        targetTest(i)=1;
    else
        targetTest(i)=2;
    end
end

if (~isempty(varargin{1}{1,1}))
    fprintf( ...
        'number of correct classifications: %i out of %i total observations\n', ...
        sum(varargin{1}{1,1}==targetTest'), size(varargin{1}{1,1},1))
end

end

